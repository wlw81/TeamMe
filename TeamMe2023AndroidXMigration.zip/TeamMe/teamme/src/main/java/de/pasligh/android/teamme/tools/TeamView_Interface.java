package de.pasligh.android.teamme.tools;

public interface TeamView_Interface {

    public void notifyAdapter();
}

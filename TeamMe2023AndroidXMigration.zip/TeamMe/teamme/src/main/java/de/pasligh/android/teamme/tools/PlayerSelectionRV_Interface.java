package de.pasligh.android.teamme.tools;

import android.view.View;
import android.widget.CompoundButton;

/**
 * Created by Thomas on 24.02.2016.
 */
public interface PlayerSelectionRV_Interface extends CompoundButton.OnCheckedChangeListener, View.OnLongClickListener {
}
